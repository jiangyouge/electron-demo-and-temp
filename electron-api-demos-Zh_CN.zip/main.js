require('update-electron-app')({
  logger: require('electron-log')
})

const path = require('path')
const glob = require('glob')
const {app, BrowserWindow} = require('electron')

const debug = /--debug/.test(process.argv[2])

if (process.mas) app.setName('Electron APIs')

let mainWindow = null

function initialize () {
  makeSingleInstance()

  loadDemos()

  function createWindow () {
    const windowOptions = {
      width: 1080,
      minWidth: 680,
      height: 840,
      title: app.getName(), // 窗口title，默认是Electron
      webPreferences: { // 设置界面特性
        nodeIntegration: true // 是否完整支持node. 默认为 false,渲染进程默认不支持
      }
    }

    if (process.platform === 'linux') {
      windowOptions.icon = path.join(__dirname, '/assets/app-icon/png/512.png')
    }

    mainWindow = new BrowserWindow(windowOptions)
    mainWindow.loadURL(path.join('file://', __dirname, '/index.html'))

    // 在打开 DevTools 的情况下全屏启动, 用法: npm run debug
    if (debug) {
      mainWindow.webContents.openDevTools()
      mainWindow.maximize()
      require('devtron').install()
    }

    mainWindow.on('closed', () => {
      mainWindow = null
    })
  }

  app.on('ready', () => { // 完成初始化，触发一次
    createWindow()
  })

  app.on('window-all-closed', () => { // Cmd+Q或者直接调用app的quit事件，此事件不会触发
    if (process.platform !== 'darwin') { // macOS系统
      app.quit() // 应用退出时发出，但系统关机/重启、用户注销，此事件不会触发
    }
  })

  app.on('activate', () => { // 首次启动应用时、与其他应用窗口切换时等
    if (mainWindow === null) {
      createWindow()
    }
  })
}

// 将此应用程序设为单个实例应用程序。
//
// 当尝试启动第二个实例时，将恢复并聚焦到主窗口，
// 而不是打开第二个窗口。
//
// 如果应用程序的当前版本应该退出而不是启动，
// 则返回true.
function makeSingleInstance () {
  if (process.mas) return

  app.requestSingleInstanceLock()

  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore()
      mainWindow.focus()
    }
  })
}

// 在主进程目录中需要的每个 JS 文件
function loadDemos () {
  console.log('__dirname == ', __dirname) // src/main
  const files = glob.sync(path.join(__dirname, 'main-process/**/*.js'))
  console.log('files == ', files) // src/main
  files.forEach((file) => { require(file) })
}

initialize()
